# 統合手順(第五輯分の追加)

前回の `INTEGRATION.md` の手順と同じ形で、今回追加した3ファイルを
配線してください。

## 1. 新規ファイルの配置

- `data/palmistry_nails.js`
- `data/palmistry_mounts.js`
- `data/palmistry_lines.js`

そのまま `data/` 配下に配置してください(UMDパターンは既存ファイルと共通)。

## 2. `data/index.js`

```js
var PALMISTRY_NAILS = require('./palmistry_nails.js');
var PALMISTRY_MOUNTS = require('./palmistry_mounts.js');
var PALMISTRY_LINES = require('./palmistry_lines.js');

var PARTS = [].concat(
  CORE, CONSTITUTION, FIVE_ELEMENTS, FACE_SHAPE, BODY, PHRENOLOGY,
  PALMISTRY, PALMISTRY_NAILS, PALMISTRY_MOUNTS, PALMISTRY_LINES
);
```

## 3. `tools/generate-index.js` の `DATA_FILES`

```js
const DATA_FILES = [
  'core.js',
  'constitution.js',
  'five_elements.js',
  'face_shape.js',
  'body.js',
  'phrenology.js',
  'palmistry.js',
  'palmistry_nails.js',   // ← 追加
  'palmistry_mounts.js',  // ← 追加
  'palmistry_lines.js',   // ← 追加
];
```

## 4. `app/index.html`

```html
<script src="../data/palmistry_nails.js"></script>
<script src="../data/palmistry_mounts.js"></script>
<script src="../data/palmistry_lines.js"></script>
```

(`data/index.js` を1本にまとめて読み込む方式なら、こちらは不要な場合あり)

## 5. `source/notes.md` / `docs/progress.md`

`source/notes_additions_5th.md` / `docs/progress_addition_5th.md` の内容を、
それぞれ既存ファイルの末尾に追記してください。

## 6. 前回(第四輯)分の未確認事項

前回渡した `data/palmistry.js` の `data/index.js` 等への実マージが
まだであれば、今回の3ファイルと合わせてまとめて配線するのが効率的です。
